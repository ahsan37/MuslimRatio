
function check(){
    var c=0;
    var q1=document.quiz.question1.value;
    var q2=document.quiz.question2.value;
    var q3=document.quiz.question3.value;
    var q4=document.quiz.question4.value;
    var q5=document.quiz.question5.value;
    var q6=document.quiz.question6.value;
    var q7=document.quiz.question7.value;
    var q8=document.quiz.question8.value;
    var q9=document.quiz.question9.value;
    var q10=document.quiz.question10.value;
    var q11=document.quiz.question11.value;
    var q12=document.quiz.question12.value;
    var q13=document.quiz.question13.value;
    var q14=document.quiz.question14.value;
    var q15=document.quiz.question15.value;
    var q16=document.quiz.question16.value;
    var q17=document.quiz.question17.value;
    var q18=document.quiz.question18.value;
    var q19=document.quiz.question19.value;
    var q20=document.quiz.question20.value;

    var result=document.getElementById('result');
    var quiz=document.getElementById("quiz");

    $('#caption-end').hide();
    
    // $('#ninteyhundred').hide();

    if(q1=="5") {c= c+5;}
    if(q1=="4") {c= c+3.75;}
    if(q1=="3") {c= c+2.5;}
    if(q1=="2") {c= c+1.25;}
    if(q1=="1") {c= c+0;}

    if(q2=="5") {c= c+5;}
    if(q2=="4") {c= c+3.75;}
    if(q2=="3") {c= c+2.5;}
    if(q2=="2") {c= c+1.25;}
    if(q2=="1") {c= c+0;}

    if(q3=="5") {c= c+5;}
    if(q3=="4") {c= c+3.75;}
    if(q3=="3") {c= c+2.5;}
    if(q3=="2") {c= c+1.25;}
    if(q3=="1") {c= c+0;}

    if(q4=="5") {c= c+5;}
    if(q4=="4") {c= c+3.75;}
    if(q4=="3") {c= c+2.5;}
    if(q4=="2") {c= c+1.25;}
    if(q4=="1") {c= c+0;}
    
    if(q5=="5") {c= c+5;}
    if(q5=="4") {c= c+3.75;}
    if(q5=="3") {c= c+2.5;}
    if(q5=="2") {c= c+1.25;}
    if(q5=="1") {c= c+0;}
    
    if(q6=="5") {c= c+5;}
    if(q6=="4") {c= c+3.75;}
    if(q6=="3") {c= c+2.5;}
    if(q6=="2") {c= c+1.25;}
    if(q6=="1") {c= c+0;}
    
    if(q7=="5") {c= c+5;}
    if(q7=="4") {c= c+3.75;}
    if(q7=="3") {c= c+2.5;}
    if(q7=="2") {c= c+1.25;}
    if(q7=="1") {c= c+0;}

    if(q8=="5") {c= c+5;}
    if(q8=="4") {c= c+3.75;}
    if(q8=="3") {c= c+2.5;}
    if(q8=="2") {c= c+1.25;}
    if(q8=="1") {c= c+0;}
    
    if(q9=="5") {c= c+5;}
    if(q9=="4") {c= c+3.75;}
    if(q9=="3") {c= c+2.5;}
    if(q9=="2") {c= c+1.25;}
    if(q9=="1") {c= c+0;}
    
    if(q10=="5") {c= c+5;}
    if(q10=="4") {c= c+3.75;}
    if(q10=="3") {c= c+2.5;}
    if(q10=="2") {c= c+1.25;}
    if(q10=="1") {c= c+0;}

    if(q11=="5") {c= c+5;}
    if(q11=="4") {c= c+3.75;}
    if(q11=="3") {c= c+2.5;}
    if(q11=="2") {c= c+1.25;}
    if(q11=="1") {c= c+0;}

    if(q12=="5") {c= c+5;}
    if(q12=="4") {c= c+3.75;}
    if(q12=="3") {c= c+2.5;}
    if(q12=="2") {c= c+1.25;}
    if(q12=="1") {c= c+0;}
    
    if(q13=="5") {c= c+5;}
    if(q13=="4") {c= c+3.75;}
    if(q13=="3") {c= c+2.5;}
    if(q13=="2") {c= c+1.25;}
    if(q13=="1") {c= c+0;}

    if(q14=="5") {c= c+5;}
    if(q14=="4") {c= c+3.75;}
    if(q14=="3") {c= c+2.5;}
    if(q14=="2") {c= c+1.25;}
    if(q14=="1") {c= c+0;}
    
    if(q15=="5") {c= c+5;}
    if(q15=="4") {c= c+3.75;}
    if(q15=="3") {c= c+2.5;}
    if(q15=="2") {c= c+1.25;}
    if(q15=="1") {c= c+0;}

    if(q16=="5") {c= c+5;}
    if(q16=="4") {c= c+3.75;}
    if(q16=="3") {c= c+2.5;}
    if(q16=="2") {c= c+1.25;}
    if(q16=="1") {c= c+0;}
    
    if(q17=="5") {c= c+5;}
    if(q17=="4") {c= c+3.75;}
    if(q17=="3") {c= c+2.5;}
    if(q17=="2") {c= c+1.25;}
    if(q17=="1") {c= c+0;}

    if(q18=="5") {c= c+5;}
    if(q18=="4") {c= c+3.75;}
    if(q18=="3") {c= c+2.5;}
    if(q18=="2") {c= c+1.25;}
    if(q18=="1") {c= c+0;}

    if(q19=="5") {c= c+5;}
    if(q19=="4") {c= c+3.75;}
    if(q19=="3") {c= c+2.5;}
    if(q19=="2") {c= c+1.25;}
    if(q19=="1") {c= c+0;}
    
    if(q20=="5") {c= c+5;}
    if(q20=="4") {c= c+3.75;}
    if(q20=="3") {c= c+2.5;}
    if(q20=="2") {c= c+1.25;}
    if(q20=="1") {c= c+0;}
    
    
    
        
    
    
    quiz.style.display="none";
    $('#caption').hide();
   
    $('#caption-end').show();
    $('#retakebutton').show();

    if(c>= 90 && c<=100 ){
        $('#ninteyhundred').show();
    }

    if(c>= 80 && c<=89.99 ){
        $('#eigthynintey').show();
    }

    if(c>= 70 && c<=79.99 ){
        $('#seventyeighty').show();
    }

    if(c>= 60 && c<=69.99 ){
        $('#sixtyseventy').show();
    }

    if(c>= 50 && c<=59.99 ){
        $('#fiftysixty').show();
    }

    if(c>= 40 && c<=49.99 ){
        $('#fourtyfifty').show();
    }

    if(c>= 30 && c<=39.99 ){
        $('#thirtyfourty').show();
    }

    if(c>= 25 && c<=29.99 ){
        $('#twentyfivethirty').show();
    }

    if(c>= 5 && c<=24.99 ){
        $('#fivetwentyfive').show();
    }
    if(c>= 0 && c<=4.99 ){
        $('#zerofive').show();
    }
    result.textContent= `${100-c}% Halal : ${c}% Haram`;
    // result.textContent= (c);
   
  
}




$(document).ready(function(){
    // var gender2=document.getElementById('male');
    // var gender = $('input[name=questiongender]:checked').val()
    $('.row-q').hide();
    $('#begind').show();
    $('#back').hide();
    $('#retakebutton').hide();


//    $('#gender #male').click(function(){
//         $('#back').show();
//         $('.row-q').hide();
//         $('#q1male').fadeIn(500);
//         return false;

//     });

//     $('#gender #female').click(function(){
//         $('#back').show();
//         $('.row-q').hide();
//         $('#q1female').fadeIn(500);
//         return false;
//     });

        
//     $('#q1male #back').click(function(){
//         $('#back').hide();
//         $('.row-q').hide();

//         $('#gender').fadeIn(500);
//         return false;

//     });

//     $('#q1male #next').click(function(){
//         $('#back').show();
//         $('.row-q').hide();
//         $('#q2').fadeIn(500);
//         return false;

//     });

//     $('#q1female #back').click(function(){
//         $('#back').hide();
//         $('.row-q').hide();
//         $('#gender').fadeIn(500);
//         return false;

//     });

   
    
//     $('#q1female #next').click(function(){
//         $('#back').show();
//         $('.row-q').hide();
//         $('#q2').fadeIn(500);
//         return false;

//     });
   // $('#q1gender #female').click(function(){
    //     $('#back').show();
    //     $('.row-q').hide();
    //     $('#q1female').fadeIn(400);
    //     return false;

    // });

    // $('#q1gender #male').click(function(){
    //     $('#back').show();
    //     $('.row-q').hide();
    //     $('#q1male').fadeIn(400);
    //     return false;

    // });

   
    // $('#q1gender #next1').click(function(){
    //     $('#back').show();
    //     $('.row-q').hide();
    //     $('#q1').fadeIn(400);

    //     return false;

    // });





     $('#begind #begin').click(function(){
        $('#back').show();
        $('.row-q').hide();
        $('#q1').fadeIn(400);
        return false;

    });

     $('#q1 #next').click(function(){
        $('#back').show();
        $('.row-q').hide();
        $('#q2').fadeIn(400);
        return false;

    });

     $('#q1 #back').click(function(){
        $('#back').show();
        $('.row-q').hide();
        $('#begind').fadeIn(400);
        return false;

    });
    // $('#q1 #back').click(function(){
    //     $('#back').hide();
    //     $('.row-q').hide();
    //     $('#q1gender').fadeIn(400);
    //     return false;

    // });


    // $('#q2 #back','#q1gender #female').click(function(){
    //         $('.row-q').hide();
    //         $('#q1female').fadeIn(500);
    //         return false;

    //     });

    // $('#q2 #back','#q1gender #female').click(function(){
    //         $('.row-q').hide();
    //         $('#q1male').fadeIn(500);
    //         return false;
    //     });
//     $('#q2 #back').click(function(){

//      if(gender != "#male" || gender != "#female"){ 
//         $('.row-q').hide();
//         $('#q1male').fadeIn(500);
//         return false;

//     } else if(gender=="#male"){
//         $('.row-q').hide();
//         $('#q1male').fadeIn(500);
//         return false;

//     }  
//     else if (gender=="#female") {
//         $('.row-q').hide();
//         $('#q1female').fadeIn(500);
//         return false;
//     } // var gender = $('input[name=questiongender]:checked').val()
// });

       
    $('#q2 #back').click(function(){
     $('#q1gender #male');{
        $('.row-q').hide();
        $('#q1').fadeIn(500);
        return false;
    };
});
       
  

    $('#q2 #next').click(function(){
        $('.row-q').hide();
        $('#q3').fadeIn(500);
        return false;

    });

    $('#q3 #back').click(function(){
        $('.row-q').hide();
        $('#q2').fadeIn(500);
        return false;

    });

    $('#q3 #next').click(function(){
        $('.row-q').hide();
        $('#q4').fadeIn(500);
        return false;

    });

    $('#q4 #back').click(function(){
        $('.row-q').hide();
        $('#q3').fadeIn(500);
        return false;

    });

    $('#q4 #next').click(function(){
        $('.row-q').hide();
        $('#q5').fadeIn(500);
       
        
        return false;
        

    });

    $('#q5 #back').click(function(){
        $('.row-q').hide();
        $('#q4').fadeIn(500);
    
        return false;
        

    });
 

    $('#q5 #next').click(function(){
        $('.row-q').hide();
        $('#q6').fadeIn(500);
       
        
        return false;
        

    });
 

    $('#q6 #back').click(function(){
        $('.row-q').hide();
        $('#q5').fadeIn(500);
    
        return false;
        

    });
 

    $('#q6 #next').click(function(){
        $('.row-q').hide();
        $('#q7').fadeIn(500);
       
        
        return false;
        

    });
 

    $('#q7 #back').click(function(){
        $('.row-q').hide();
        $('#q6').fadeIn(500);
    
        return false;
        

    });
 

    $('#q7 #next').click(function(){
        $('.row-q').hide();
        $('#q8').fadeIn(500);
       
        
        return false;
        

    });
 
    $('#q8 #back').click(function(){
        $('.row-q').hide();
        $('#q7').fadeIn(500);
    
        return false;
        

    });
 

    $('#q8 #next').click(function(){
        $('.row-q').hide();
        $('#q9').fadeIn(500);
       
        
        return false;
        

    });
 
    $('#q9 #back').click(function(){
        $('.row-q').hide();
        $('#q8').fadeIn(500);
    
        return false;
        

    });

    $('#q9 #next').click(function(){
        $('.row-q').hide();
        $('#q10').fadeIn(500);
       
        
        return false;
        

    });
 
     
    $('#q10 #back').click(function(){
        $('.row-q').hide();
        $('#q9').fadeIn(500);
    
        return false;
        

    });

    $('#q10 #next').click(function(){
        $('.row-q').hide();
        $('#q11').fadeIn(500);
       
        
        return false;
        

    });

     
    $('#q11 #back').click(function(){
        $('.row-q').hide();
        $('#q10').fadeIn(500);
    
        return false;
        

    });

    $('#q11 #next').click(function(){
        $('.row-q').hide();
        $('#q12').fadeIn(500);
       
        
        return false;
        

    });
 
     
    $('#q12 #back').click(function(){
        $('.row-q').hide();
        $('#q11').fadeIn(500);
    
        return false;
        

    });

    $('#q12 #next').click(function(){
        $('.row-q').hide();
        $('#q13').fadeIn(500);
       
        
        return false;
        

    });

     
    $('#q13 #back').click(function(){
        $('.row-q').hide();
        $('#q12').fadeIn(500);
    
        return false;
        

    });

    $('#q13 #next').click(function(){
        $('.row-q').hide();
        $('#q14').fadeIn(500);
       
        
        return false;
        

    });

     
    $('#q14 #back').click(function(){
        $('.row-q').hide();
        $('#q13').fadeIn(500);
    
        return false;
        

    });

    $('#q14 #next').click(function(){
        $('.row-q').hide();
        $('#q15').fadeIn(500);
       
        
        return false;
        

    });

     
    $('#q15 #back').click(function(){
        $('.row-q').hide();
        $('#q14').fadeIn(500);
    
        return false;
        

    });

    $('#q15 #next').click(function(){
        $('.row-q').hide();
        $('#q16').fadeIn(500);
       
        
        return false;
        

    });
 
  
    $('#q16 #back').click(function(){
        $('.row-q').hide();
        $('#q15').fadeIn(500);
    
        return false;
        

    });

    $('#q16 #next').click(function(){
        $('.row-q').hide();
        $('#q17').fadeIn(500);
       
        
        return false;
        

    });
 
  
    $('#q17 #back').click(function(){
        $('.row-q').hide();
        $('#q16').fadeIn(500);
    
        return false;
        

    });

    $('#q17 #next').click(function(){
        $('.row-q').hide();
        $('#q18').fadeIn(500);
       
        
        return false;
        

    });
 
     
    $('#q18 #back').click(function(){
        $('.row-q').hide();
        $('#q17').fadeIn(500);
    
        return false;
        

    });

    $('#q18 #next').click(function(){
        $('.row-q').hide();
        $('#q19').fadeIn(500);
       
        
        return false;
        

    });
 
     
    $('#q19 #back').click(function(){
        $('.row-q').hide();
        $('#q18').fadeIn(500);
    
        return false;
        

    });

    $('#q19 #next').click(function(){
        $('.row-q').hide();
        $('#q20').fadeIn(500);
       
        
        return false;
        

    });

    $('#q20 #back').click(function(){
        $('.row-q').hide();
        $('#q19').fadeIn(500);
    
        return false;
        

    });


 
 
    $('#q20 #next').click(function(){
        $('.row-q').hide();
        $('#next').hide();
        
        return false;

    });

    $('#question20 #submitbutton').click(function(){
        $('.row-q').hide();
        
    
    
    });






});


$(document).ready(function(){

    $('.js--scroll-to-quiz').click(function(){
        $('html, body').animate({scrollTop:$('.js--section-quiz').offset().top},1000)
    });

    $('.js--scroll-to-what').click(function(){
        $('html, body').animate({scrollTop:$('.js--section-what').offset().top},1000)
    });



    $('.js--nav-icon').click(function(){
        var nav = $('.js--main-nav');
        var icon = $('.js--nav-icon i');
        nav.slideToggle(200);

        if(icon.hasClass('ion-navicon-round')){
            icon.addClass('ion-close-round');
            icon.removeClass('ion-navicon-round');

        } else{
            icon.addClass('ion-navicon-round');
            icon.removeClass('ion-close-round');

        }

    });

    
    });

