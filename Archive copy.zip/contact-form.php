
<?php

// echo"<pre>";
//    print_r($_POST);
// echo'</pre>';
    $message_sent = false;

    if(isset($_POST['email']) && $_POST['email'] =! ''){

        if(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){


            $userName= $_POST['name'];
            $userEmail=$_POST['email'];
            $messageSubject=$_POST['subject'];
            $message=$_POST['message'];
         
            $to= "wahsan77@yahoo.com";
            $body="";
         
            $body .="From: ".$userName. "\r\n";
            $body .="Email: ".$userEmail. "\r\n";
            $body .="Message: ".$message. "\r\n";
         
         
            mail($to,$messageSubject,$body);

            $message_sent = true;


        }

    }


?>

<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"content ="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="vendors/css/normalize.css">
        <link rel="stylesheet" type="text/css" href="vendors/css/grid.css">
        <script src="resources/css/jquery.js"></script>
        <script type="text/javascript" src="resources/data/quiz.js"></script>
        <link rel="stylesheet" type="text/css" href="resources/css/style.css">
        <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;1,300&display=swap" rel="stylesheet">

        <title>MuslimRatio</title>


    </head>
    <body>

    <?php

    if($message_sent):
?>

        <h3> Thanks, we'll be in touch!</h3>

        <?php

             else:

        ?>
        <section class="section-contact">
            <nav>
                <div class="row">
                   <img src="resources/img/HHlogo.png" alt="H:H Logo" class="logo">
                    <ul class="main-nav">
                        <li><a href="index.html">Ratio Quiz</a></li>
                        <li><a href="#">Personality Types</a></li>
                        <li><a href="#">About Me</a></li>
                        <li><a href="contact.html">Contact</a></li>
                    </ul>
                    <!-- <ul class="main-nav-logo">
                        <li><a href="index.html">H:H</li>

                    </ul> -->
                </div>
               


                <div class="container">
                    <form action="contact-form.php" method="POST" class="form">
                        <div class="form-group">
                            <label for="name" class="form-label">Your Name</label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="Naval Ravikant" tabindex="1" required>
                        </div>
                        <div class="form-group">
                            <label for="email" class="form-label">Your Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="naval@ravikant.com" tabindex="2" required>
                        </div>
                        <div class="form-group">
                            <label for="subject" class="form-label">Subject</label>
                            <input type="text" class="form-control" id="subject" name="subject" placeholder="What's Up!" tabindex="3" >

                        </div>
                        <div class="form-group">
                            <label for="" class="form-label">Message</label>
                            <textarea class="form-control" rows="5" cols="40" id="message" name="message" placeholder="Your Message..." tabindex="4" required></textarea>
                        </div>
                        <div>
                            <button id="sendbutton" type="submit" tabindex="5">Send Message!</button>
                        </div>


                    </form>
                </div>
            </nav>
     
    </section>

        <?php
         endif;
         ?>

    </body>
        